import streamlit as st
import pandas as pd
import joblib
from pathlib import Path

st.set_page_config(page_title='Credit Scoring – Fintech & Banking', page_icon='💳', layout='centered')
st.title('Hệ thống Đánh giá Điểm tín dụng (Fintech & Banking)')

st.markdown('**Lưu ý:** Nếu chưa có mô hình trong thư mục `models/`, ứng dụng sẽ dùng chế độ mô phỏng để demo.')

def load_model():
    candidates = ['models/xgboost.pkl', 'models/logistic_regression.pkl', 'models/random_forest.pkl']
    for c in candidates:
        if Path(c).exists():
            return joblib.load(c)
    return None

model = load_model()

with st.form('credit_form'):
    st.header('Nhập thông tin khách hàng')
    age = st.number_input('Tuổi', min_value=18, max_value=100, value=30)
    income = st.number_input('Thu nhập hàng năm ($)', min_value=0, value=12000)
    inhand = st.number_input('Lương thực nhận hàng tháng ($)', min_value=0, value=1000)
    num_acc = st.number_input('Số tài khoản ngân hàng', min_value=0, value=2)
    num_card = st.number_input('Số thẻ tín dụng', min_value=0, value=1)
    rate = st.number_input('Lãi suất hiện tại (%)', min_value=0, value=12)
    num_loan = st.number_input('Số khoản vay hiện tại', min_value=0, value=1)
    occupation = st.selectbox('Nghề nghiệp', ['Software Engineer','Doctor','Teacher','Sales','Khác'])
    loan_type = st.selectbox('Loại hình khoản vay', ['Personal','Auto','Mortgage','BNPL','P2P'])
    delay = st.number_input('Số ngày trễ hạn trung bình', min_value=0, value=0)

    submitted = st.form_submit_button('Đánh giá')

if submitted:
    X = pd.DataFrame([{
        'Age': age,
        'Annual_Income': income,
        'Monthly_Inhand_Salary': inhand,
        'Num_Bank_Accounts': num_acc,
        'Num_Credit_Card': num_card,
        'Interest_Rate': rate,
        'Num_of_Loan': num_loan,
        'Occupation': occupation,
        'Type_of_Loan': loan_type,
        'Delay_from_due_date': delay
    }])

    if model is not None:
        try:
            pred = model.predict(X)[0]
            proba = model.predict_proba(X)[0] if hasattr(model, 'predict_proba') else None
            st.success(f'Kết quả: Nhóm tín dụng **{pred}**')
            if proba is not None and hasattr(model, 'classes_'):
                st.subheader('Xác suất từng nhóm')
                for cls, p in zip(model.classes_, proba):
                    st.write(f'- {cls}: {p:.2%}')
        except Exception as e:
            st.warning('Không tương thích pipeline. Chuyển sang mô phỏng.')
            model = None

    if model is None:
        # Chế độ mô phỏng đơn giản
        score = 0
        score += (income/10000) * 0.3
        score += (inhand/1000) * 0.2
        score += max(0, 3 - num_loan) * 0.2
        score += max(0, 3 - delay/10) * 0.2
        score += max(0, 3 - rate/10) * 0.1
        label = 'Tốt' if score >= 1.2 else ('Trung bình' if score >= 0.8 else 'Kém')
        st.info(f'Kết quả (mô phỏng): Nhóm tín dụng **{label}**')

st.divider()
st.caption('© Nhóm 10 – Đánh giá điểm tín dụng cá nhân trong Fintech & Banking')
