Đặt file mô hình đã huấn luyện (.pkl) tại đây. Ví dụ: xgboost.pkl hoặc logistic_regression.pkl.
Nếu không có, app sẽ chạy ở chế độ mô phỏng.